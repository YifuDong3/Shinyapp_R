library(ggplot2)
library(readr)
library(tidyverse)
library(shiny)

#cleaning data
finalbaseball <- read_csv("app4/finalbaseball.csv")
finalbasketball <-  read_csv("app4/finalbasket.csv")
finalbasket_three = finalbasketball[41:179,]

######data transformation for precipitation ----basketball
#cleaning data
bask <- finalbasketball
mean.prcp <- mean(bask$PRCP)
sd.prcp <- sd(bask$PRCP)
bask$prcp <- bask$PRCP
bask$prcp[0 < bask$PRCP & bask$PRCP < mean.prcp] = 1
bask$prcp[mean.prcp <= bask$PRCP & bask$PRCP < (mean.prcp + sd.prcp)] = 2 
bask$prcp[(mean.prcp + sd.prcp) <= bask$PRCP & bask$PRCP < (mean.prcp + 2*sd.prcp)] = 3
bask$prcp[bask$PRCP > (mean.prcp + 2*sd.prcp)] = 4
# Compute the mean attendance in each precipitation group
avg.bask <- bask %>%
  group_by(prcp) %>%   
  summarise(avg.bask = mean(ATTENDANCE))


######data transformation for precipitation ----baseball
base.prcp <- finalbaseball
mean.prcp <- mean(base.prcp$PRCP)
sd.prcp <- sd(base.prcp$PRCP)
# Add a catogorical variable of precipitation
base.prcp$prcp <- base.prcp$PRCP
base.prcp$prcp[0 < base.prcp$PRCP & base.prcp$PRCP < mean.prcp] = 1
base.prcp$prcp[mean.prcp <= base.prcp$PRCP & base.prcp$PRCP < (mean.prcp + sd.prcp)] = 2 
base.prcp$prcp[(mean.prcp + sd.prcp) <= base.prcp$PRCP & base.prcp$PRCP < (mean.prcp + 2*sd.prcp)] = 3
base.prcp$prcp[base.prcp$PRCP > (mean.prcp + 2*sd.prcp)] = 4
# Compute the mean attendance in each precipitation group
avg.base <- base.prcp %>%
  group_by(prcp) %>%   
  summarise(avg.base = mean(Attendance))



if (interactive()) {
  
  ui <- navbarPage("The relationship between attendance and weather",
                   tabPanel("Baseball",
                            sidebarLayout(
                              sidebarPanel(
                                selectizeInput("plotType1", label="Please choose the variable against attendance you want to see:",
                                               choices=c("Temperature","Temp_five years","Average Wind Speed","Precipitation(mm)","Average attendance from years","WT02(Heaving freezing fog, ice)",
                                              "WT03(Thunder)","WT08(Smoke or haze)","WT09(Blowing and drifting snow)"),multiple=F,options = list(create = TRUE,placeholder = 'Choose the year')
                                ),
                                
                                sliderInput("r_num_years", "Number of years you want to see",
                                            2012, 2017, 1)
                              ),
                              
                              mainPanel(
                                tabPanel("Plot", plotOutput("distPlot"))
                              )
                            )
                   ),
                   tabPanel("Basketball",
                            sidebarLayout(
                              sidebarPanel(
                                selectizeInput("plotType", label="Please choose the variable against attendance you want to see:",
                                               choices=c("Temperature_Four years","Temperature_Line","Average Wind Speed","Precipitation(mm)","Average attendance from years1","WT02(Heaving freezing fog, ice)",
                                                         "WT03(Thunder)","WT08(Smoke or haze)","WT09(Blowing and drifting snow)"),multiple=F,options = list(create = TRUE,placeholder = 'Choose the year')
                                ),
                                sliderInput("r_num_years1", "Number of years you want to see(For basketball we remove year of 2012&2017)",
                                            2013, 2016, 1)
                              ),
                              mainPanel(
                                tabPanel(
                                  "Plot2",plotOutput("disPlot2"))
                              )
                            )        
                   ),
                   tabPanel("What's interesting",
                            
                             sidebarPanel("
In 2012, most of the time the attendance number is more than 37000, which is unbelievable;
In 2013, the attendance number is more scattered, which means the fans are less crazy.----In 2012, Red Sox finished last in the five-team American League East,
while in 2013,  the Red Sox finished first in the American League East."),
                            
                              mainPanel(
                                tabsetPanel(
                                  tabPanel("The fans of Red Sox", plotOutput("Plot3")) 
                                )
                              )
                            
                            )
                   )
  
  
  
  
  
  
  
  
  
  
  ###################################################################
  server <- function(input, output,session) {
    
    
    output$distPlot <- renderPlot({
      time <- input$r_num_years
      changefinalbaseball <- filter(finalbaseball,finalbaseball$YYYY<(time+1))

      
      if(input$plotType1 == "Temperature"){
        ggplot(changefinalbaseball, aes(x=changefinalbaseball$`TAVG(temprature avg)`, y=changefinalbaseball$Attendance, color=changefinalbaseball$YYYY)) + geom_point()+
          geom_smooth(se=FALSE)
      }
      else if(input$plotType1 == "Temp_five years"){
        ggplot(changefinalbaseball, aes(x=changefinalbaseball$`TAVG(temprature avg)`, y=changefinalbaseball$Attendance, group=changefinalbaseball$YYYY,color=YYYY)) + geom_point()+
          geom_smooth(se=FALSE)}
      
      else if(input$plotType1 == "Average Wind Speed"){
        ggplot(data = changefinalbaseball, mapping = aes(x = changefinalbaseball$`AWND(avg wind speed)`, y =changefinalbaseball$Attendance, color=changefinalbaseball$YYYY)) + geom_point() + 
          geom_smooth(se =FALSE)
      }
      else if(input$plotType == "Average attendance from years1"){
        ggplot(data = changefinalbaseball, mapping = aes(x = YYYY, y =Attendance, color=YYYY)) + geom_point() + 
          geom_smooth(se =FALSE)
      }
      else if(input$plotType1 == "Average attendance from years"){
        p <- ggplot(data = changefinalbaseball, mapping = aes(x = YYYY, y = Attendance,group=YYYY,color=YYYY))+
          geom_jitter(height=0.1,size=1, alpha=0.4)
        p+geom_boxplot()
      }
      else if(input$plotType1=="WT02(Heaving freezing fog, ice)"){
        ggplot(data = changefinalbaseball,mapping = aes(y=changefinalbaseball$WT02,x=changefinalbaseball$Attendance,color=YYYY))+
          geom_jitter(height=0.05,size=1, alpha=0.4)+
          geom_smooth(se = FALSE)}
      else if(input$plotType1=="WT03(Thunder)"){
        ggplot(data = changefinalbaseball,mapping = aes(y=changefinalbaseball$WT03,x=changefinalbaseball$Attendance,color=YYYY))+
          geom_jitter(height=0.05,size=1, alpha=0.4)+
          geom_smooth(se = FALSE)}
      else if(input$plotType1=="WT08(Smoke or haze)"){
        ggplot(data = changefinalbaseball,mapping = aes(y=changefinalbaseball$WT08,x=changefinalbaseball$Attendance,color=YYYY))+
          geom_jitter(height=0.05,size=1, alpha=0.4)+
          geom_smooth(se = FALSE)}
      else if(input$plotType1=="WT09(Blowing and drifting snow)"){
        ggplot(data = changefinalbaseball,mapping = aes(y=changefinalbaseball$WT09,x=changefinalbaseball$Attendance,color=YYYY))+
          geom_jitter(height=0.05,size=1, alpha=0.4)+
          geom_smooth(se = FALSE)}
      else if(input$plotType1 =="Precipitation(mm)"){
        ggplot(data = avg.base) + 
          geom_line(mapping = aes(x=prcp, y=avg.base), color='green', size = 1) + 
          xlab("Degree of Precipitation") + ylab(" Basketball Game Attendance")
      }
      
    })
    
    
    output$disPlot2 <- renderPlot({
      
      time1 <- input$r_num_years1
      changefinalbasketball <- filter(finalbasketball,finalbasketball$YEAR<(time1+1))
      changefinalbasketball1 <- filter(finalbasket_three,finalbasket_three$YEAR<(time1+1))
      
      if(input$plotType == "Temperature_Four years"){
        ggplot(changefinalbasketball1, aes(x=changefinalbasketball1$`TAVG(temprature avg)`, y=changefinalbasketball1$ATTENDANCE, color=changefinalbasketball1$YEAR)) + geom_point()+
          geom_smooth(se=FALSE)}
      
      else if(input$plotType == "Temperature_Line"){
        ggplot(changefinalbasketball1, aes(x=changefinalbasketball1$`TAVG(temprature avg)`, y=changefinalbasketball1$ATTENDANCE, group=YEAR,color=YEAR)) + geom_point()+
          geom_smooth(se=FALSE)}
      
      else if(input$plotType == "Average Wind Speed"){
        ggplot(changefinalbasketball1, mapping = aes(x = changefinalbasketball1$`AWND(avg wind speed)`, y = changefinalbasketball1$ATTENDANCE, color=YEAR)) + geom_point() +
          geom_smooth(se = FALSE)}
      
      else if(input$plotType == "Average attendance from years1"){
        ggplot(data = changefinalbasketball1, mapping = aes(x = changefinalbasketball1$YEAR, y =changefinalbasketball1$ATTENDANCE, color=YEAR)) + geom_point() + 
          geom_jitter(width = 0.1,size=1, alpha=0.4)+
          geom_smooth(se =FALSE)
      }
      else if(input$plotType1 == "Average attendance from years"){
       ggplot(data = finalbasketball, mapping = aes(x = YEAR, y = ATTENDANCE,group=YEAR,color=YEAR))+
          geom_point() + 
          geom_jitter(weight=0.5,size=1, alpha=0.4)+
          geom_boxplot()
        
      }
      else if(input$plotType=="WT02(Heaving freezing fog, ice)"){
        ggplot(data = changefinalbasketball1,mapping = aes(y=changefinalbasketball1$WT02,x=changefinalbasketball1$ATTENDANCE,color=YEAR))+
          geom_jitter(height=0.05,size=1, alpha=0.4)+
          geom_smooth(se = FALSE)}
      else if(input$plotType=="WT03(Thunder)"){
        ggplot(data = changefinalbasketball1,mapping = aes(y=changefinalbasketball1$WT03,x=changefinalbasketball1$ATTENDANCE,color=YEAR))+
          geom_jitter(height=0.05,size=1, alpha=0.4)+
          geom_smooth(se = FALSE)}
      else if(input$plotType=="WT08(Smoke or haze)"){
        ggplot(data = changefinalbasketball1,mapping = aes(y=changefinalbasketball1$WT08,x=changefinalbasketball1$ATTENDANCE,color=YEAR))+
          geom_jitter(height=0.05,size=1, alpha=0.4)+
          geom_smooth(se = FALSE)}
      else if(input$plotType=="WT09(Blowing and drifting snow)"){
        ggplot(data = changefinalbasketball1,mapping = aes(y=changefinalbasketball1$WT09,x=changefinalbasketball1$ATTENDANCE,color=YEAR))+
          geom_jitter(height=0.05,size=1, alpha=0.4)+
          geom_smooth(se = FALSE)}
      else if(input$plotType =="Precipitation(mm)"){
        ggplot(data = avg.base) + 
          geom_line(mapping = aes(x=prcp, y=avg.base), color='red', size = 1) + 
          xlab("Degree of Precipitation") + ylab(" Baseball Game Attendance")
      } 
    })
    
    output$Plot3 <- renderPlot({
      ggplot(data=finalbaseball,mapping = aes(y=finalbaseball$Attendance,x=finalbaseball$YYYY))+
        geom_point(position = position_jitter(height=0.3,width = 0.1))+
        xlab("YEAR") + ylab(" Red Sox Attendance")
      
    })
  }
  
  shinyApp(ui=ui, server=server)
  
}